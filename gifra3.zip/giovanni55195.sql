-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: m-51.th.seeweb.it
-- Creato il: Ago 19, 2025 alle 17:18
-- Versione del server: 5.7.22
-- Versione PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `giovanni55195`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `avvisi`
--

CREATE TABLE `avvisi` (
  `id` int(11) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` text NOT NULL,
  `urgente` tinyint(1) DEFAULT '0',
  `data_scadenza` date DEFAULT NULL,
  `creato_il` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `calciatori`
--

CREATE TABLE `calciatori` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `data_nascita` date NOT NULL,
  `luogo_nascita` varchar(100) NOT NULL,
  `codice_fiscale` varchar(16) NOT NULL,
  `indirizzo` varchar(255) NOT NULL,
  `id_genitore` int(11) NOT NULL,
  `categoria` enum('Piccoli Amici','Primi Calci','Pulcini','Esordienti','Giovanissimi','Allievi') NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `doc_tipo` varchar(50) DEFAULT NULL,
  `doc_numero` varchar(50) DEFAULT NULL,
  `doc_emittente` varchar(100) DEFAULT NULL,
  `doc_scadenza` date DEFAULT NULL,
  `doc_file` varchar(255) DEFAULT NULL,
  `tessera_figc` varchar(50) DEFAULT NULL,
  `tessera_data_emissione` date DEFAULT NULL,
  `tessera_data_scadenza` date DEFAULT NULL,
  `certificato_data_rilascio` date DEFAULT NULL,
  `certificato_data_scadenza` date DEFAULT NULL,
  `certificato_file` varchar(255) DEFAULT NULL,
  `modulo_iscrizione` varchar(255) DEFAULT NULL,
  `genitore_fiscale` varchar(3) NOT NULL,
  `cognome_fiscale` varchar(100) NOT NULL,
  `nome_fiscale` varchar(100) NOT NULL,
  `cf_fiscale` varchar(16) NOT NULL,
  `data_nascita_fiscale` date NOT NULL,
  `indirizzo_fiscale` varchar(255) NOT NULL,
  `approvato` tinyint(1) DEFAULT '0',
  `creato_il` datetime DEFAULT CURRENT_TIMESTAMP,
  `luogo_nascita_fiscale` varchar(100) DEFAULT NULL,
  `provincia_nascita_fiscale` varchar(50) DEFAULT NULL,
  `comune_residenza_fiscale` varchar(100) DEFAULT NULL,
  `provincia_residenza_fiscale` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `calendario`
--

CREATE TABLE `calendario` (
  `id` int(11) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `data_ora` datetime NOT NULL,
  `avversario` varchar(100) NOT NULL,
  `luogo` varchar(100) NOT NULL,
  `risultato` varchar(20) DEFAULT NULL,
  `note` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `distinte`
--

CREATE TABLE `distinte` (
  `id` int(11) NOT NULL,
  `id_gara` int(11) NOT NULL,
  `id_calciatore` int(11) NOT NULL,
  `ruolo` enum('capitano','vice_capitano','titolare','riserva') DEFAULT NULL,
  `numero_maglia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `quote`
--

CREATE TABLE `quote` (
  `id` int(11) NOT NULL,
  `id_calciatore` int(11) DEFAULT NULL,
  `id_socio` int(11) DEFAULT NULL,
  `tipo` enum('iscrizione','mensile','annuale','una_tantum') NOT NULL,
  `importo` decimal(6,2) NOT NULL,
  `scadenza` date NOT NULL,
  `pagato` tinyint(1) DEFAULT '0',
  `ricevuta` varchar(255) DEFAULT NULL,
  `anno_sportivo` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `luogo_nascita` varchar(100) NOT NULL DEFAULT 'Milazzo',
  `provincia_nascita` varchar(2) NOT NULL DEFAULT 'ME',
  `data_nascita` date DEFAULT NULL,
  `codice_fiscale` varchar(16) DEFAULT NULL,
  `indirizzo` varchar(255) DEFAULT NULL,
  `comune_residenza` varchar(100) NOT NULL DEFAULT 'Milazzo',
  `provincia_residenza` varchar(2) NOT NULL DEFAULT 'ME',
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ruolo` enum('presidente','segretario','allenatore','genitore','socio','consigliere') NOT NULL,
  `approvato` tinyint(1) DEFAULT '0',
  `creato_il` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `luogo_nascita`, `provincia_nascita`, `data_nascita`, `codice_fiscale`, `indirizzo`, `comune_residenza`, `provincia_residenza`, `email`, `password`, `ruolo`, `approvato`, `creato_il`) VALUES
(13, 'Mario', 'Rossi', 'Messina', 'ME', '1954-05-24', 'BRRGNN24E54F158T', 'Piazza San Papino, 35', 'Milazzo', 'ME', 'presidente2024@giovannicusumano.it', '$2y$12$Thus8pXSC/KuIXWgMfqxYu1AlEU9sWVt6c/HXfreVuUQx5SgKQiRW', 'presidente', 1, '2025-08-15 21:57:30'),
(16, 'Eriberto', 'Carlino', 'Limerì', 'ME', '1988-12-12', 'CSMKLO87U54T532E', 'Via de la smorfia, 33', 'Limerì', 'ME', 'carlino.eriberto@tiscali.it', '$2y$12$/JFXu5OYciqXGUspNk61p.LOzMAymoVVmdzDEOFfPGa.1NTadCGzu', 'genitore', 1, '2025-08-18 10:46:14');

-- --------------------------------------------------------

--
-- Struttura della tabella `verbali`
--

CREATE TABLE `verbali` (
  `id` int(11) NOT NULL,
  `tipo` enum('consiglio','assemblea') NOT NULL,
  `data` date NOT NULL,
  `oggetto` varchar(255) NOT NULL,
  `file_pdf` varchar(255) NOT NULL,
  `creato_il` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `avvisi`
--
ALTER TABLE `avvisi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `calciatori`
--
ALTER TABLE `calciatori`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codice_fiscale` (`codice_fiscale`),
  ADD KEY `id_genitore` (`id_genitore`);

--
-- Indici per le tabelle `calendario`
--
ALTER TABLE `calendario`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `distinte`
--
ALTER TABLE `distinte`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_gara` (`id_gara`),
  ADD KEY `id_calciatore` (`id_calciatore`);

--
-- Indici per le tabelle `quote`
--
ALTER TABLE `quote`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_calciatore` (`id_calciatore`),
  ADD KEY `id_socio` (`id_socio`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `verbali`
--
ALTER TABLE `verbali`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `avvisi`
--
ALTER TABLE `avvisi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `calciatori`
--
ALTER TABLE `calciatori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `calendario`
--
ALTER TABLE `calendario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `distinte`
--
ALTER TABLE `distinte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `quote`
--
ALTER TABLE `quote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT per la tabella `verbali`
--
ALTER TABLE `verbali`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `calciatori`
--
ALTER TABLE `calciatori`
  ADD CONSTRAINT `calciatori_ibfk_1` FOREIGN KEY (`id_genitore`) REFERENCES `utenti` (`id`) ON DELETE CASCADE;

--
-- Limiti per la tabella `distinte`
--
ALTER TABLE `distinte`
  ADD CONSTRAINT `distinte_ibfk_1` FOREIGN KEY (`id_gara`) REFERENCES `calendario` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `distinte_ibfk_2` FOREIGN KEY (`id_calciatore`) REFERENCES `calciatori` (`id`) ON DELETE CASCADE;

--
-- Limiti per la tabella `quote`
--
ALTER TABLE `quote`
  ADD CONSTRAINT `quote_ibfk_1` FOREIGN KEY (`id_calciatore`) REFERENCES `calciatori` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quote_ibfk_2` FOREIGN KEY (`id_socio`) REFERENCES `utenti` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
