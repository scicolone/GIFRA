<?php
require_once 'tcpdf/tcpdf.php';

// Dati calciatore
$nome = $_GET['nome'] ?? '';
$cognome = $_GET['cognome'] ?? '';
$data_nascita = $_GET['data_nascita'] ?? '';
$luogo_nascita = $_GET['luogo_nascita'] ?? '';
$codice_fiscale = $_GET['codice_fiscale'] ?? '';
$indirizzo = $_GET['indirizzo'] ?? '';

// Categoria automatica
$anno = (int)substr($data_nascita, 0, 4);
if ($anno >= 2020) $categoria = 'Piccoli Amici';
elseif ($anno >= 2019) $categoria = 'Primi Calci';
elseif ($anno >= 2017) $categoria = 'Pulcini';
elseif ($anno >= 2015) $categoria = 'Esordienti';
elseif ($anno >= 2013) $categoria = 'Giovanissimi';
elseif ($anno >= 2011) $categoria = 'Allievi';
else $categoria = 'Allievi';

// Dati primo genitore (loggato)
$stmt = $pdo->prepare("SELECT nome, cognome, data_nascita, codice_fiscale, indirizzo FROM utenti WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$gen1 = $stmt->fetch(PDO::FETCH_ASSOC);

// Secondo genitore (se diverso)
$gen2 = [
    'cognome' => $_GET['cognome_fiscale'] ?? '',
    'nome' => $_GET['nome_fiscale'] ?? '',
    'cf' => $_GET['cf_fiscale'] ?? '',
    'data' => $_GET['data_nascita_fiscale'] ?? '',
    'indirizzo' => $_GET['indirizzo_fiscale'] ?? '',
    'luogo_nascita' => $_GET['luogo_nascita_fiscale'] ?? '',
    'provincia_nascita' => $_GET['provincia_nascita_fiscale'] ?? '',
    'comune_residenza' => $_GET['comune_residenza_fiscale'] ?? '',
    'provincia_residenza' => $_GET['provincia_residenza_fiscale'] ?? ''
];

// Se stesso
if (($_GET['genitore_fiscale'] ?? 'si') === 'si') {
    $gen2 = $gen1;
}

// PDF identico al modello
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, 'A4', true, 'UTF-8', false);
$pdf->SetCreator('A.S.D. Gi.Fra. Milazzo');
$pdf->SetTitle('Modulo Iscrizione');
$pdf->SetMargins(15, 20, 15);
$pdf->AddPage();

$html = '
<h1 style="text-align:center;">A.S.D. Gi.Fra. Milazzo</h1>
<h2 style="text-align:center;">ANNO SPORTIVO 2024/25<br>MODULO ISCRIZIONE</h2>
<p><strong>Alla S.S.D. Gioventù Francescana Milazzo (GI.FRA.MILAZZO)<br>Piazza San Papino, 3 – 98057 Milazzo (ME)</strong></p>

<p>Il sottoscritto <strong>' . htmlspecialchars($gen1['cognome']) . ' ' . htmlspecialchars($gen1['nome']) . '</strong> padre/madre del giovane calciatore <strong>' . htmlspecialchars($cognome) . ' ' . htmlspecialchars($nome) . '</strong><br>
nato a <strong>' . htmlspecialchars($luogo_nascita) . '</strong> il <strong>' . htmlspecialchars($data_nascita) . '</strong><br>
residente in <strong>' . htmlspecialchars($indirizzo) . '</strong><br>
codice fiscale <strong>' . htmlspecialchars($codice_fiscale) . '</strong><br>
<strong>Categoria: ' . htmlspecialchars($categoria) . '</strong></p>

<p><strong>DAT