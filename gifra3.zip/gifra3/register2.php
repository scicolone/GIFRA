<form method="POST">
    <div class="mb-3"><label>Nome</label><input type="text" name="nome" class="form-control" required></div>
    <div class="mb-3"><label>Cognome</label><input type="text" name="cognome" class="form-control" required></div>
    <div class="mb-3"><label>Luogo di nascita</label><input type="text" name="luogo_nascita" class="form-control" required></div>
    <div class="mb-3"><label>Provincia di nascita</label><input type="text" name="provincia_nascita" class="form-control" required></div>
    <div class="mb-3"><label>Data di nascita</label><input type="date" name="data_nascita" class="form-control" required></div>
    <div class="mb-3"><label>Codice fiscale</label><input type="text" name="codice_fiscale" class="form-control" required></div>
    <div class="mb-3"><label>Indirizzo</label><input type="text" name="indirizzo" class="form-control" required></div>
    <div class="mb-3"><label>Comune di residenza</label><input type="text" name="comune_residenza" class="form-control" required></div>
    <div class="mb-3"><label>Provincia di residenza</label><input type="text" name="provincia_residenza" class="form-control" required></div>
    <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
    <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
    <button type="submit" class="btn btn-primary w-100">Registrati</button>
</form>