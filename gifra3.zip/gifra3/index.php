<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>A.S.D. Gi.Fra. Milazzo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #dc3545, #0d6efd);
            color: white;
            font-family: 'Segoe UI', sans-serif;
        }
        .logo {
            max-width: 200px;
            margin-bottom: 30px;
        }
        .btn-custom {
            background-color: white;
            color: #0d6efd;
            font-weight: bold;
        }
    </style>
</head>
<body class="text-center py-5">
    <img src="logo.png" alt="Logo Gi.Fra. Milazzo" class="logo">
    <h1 class="mb-3">A.S.D. Gi.Fra. Milazzo</h1>
    <?php if (isset($_GET['registrato'])): ?>
    <div class="alert alert-warning mx-auto" style="max-width: 500px;">
        ✅ Registrazione completata! Attendi l'approvazione del Presidente o Segretario.
    </div>
<?php endif; ?>
    <p class="lead mb-4">Benvenuti nel sistema di gestione sportiva della nostra società.</p>
    <div class="d-grid gap-2 col-6 mx-auto">
        <a href="login.php" class="btn btn-custom btn-lg">Accedi</a>
        <a href="register.php" class="btn btn-outline-light btn-lg">Iscrivi tuo figlio</a>
    </div>
</body>
</html>