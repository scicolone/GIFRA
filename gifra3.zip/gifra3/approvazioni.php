<?php
include 'config.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['ruolo'], ['presidente', 'segretario'])) {
    die("Non autorizzato.");
}

// Approvazione
if (isset($_GET['approva'])) {
    $id = (int)$_GET['approva'];
    $pdo->prepare("UPDATE utenti SET approvato = 1 WHERE id = ?")->execute([$id]);
    header("Location: approvazioni.php");
    exit;
}

// Lista utenti non approvati
$stmt = $pdo->prepare("SELECT * FROM utenti WHERE approvato = 0 AND ruolo = 'genitore'");
$stmt->execute();
$utenti = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Approva Genitori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h2>Genitori da approvare</h2>
    <table class="table table-bordered">
        <tr><th>Nome</th><th>Cognome</th><th>Email</th><th>Azione</th></tr>
        <?php foreach ($utenti as $u): ?>
        <tr>
            <td><?= htmlspecialchars($u['nome']) ?></td>
            <td><?= htmlspecialchars($u['cognome']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><a href="approvazioni.php?approva=<?= $u['id'] ?>" class="btn btn-success btn-sm">Approva</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<div class="text-center mt-4">
    <a href="dashboard.php" class="btn btn-primary">← Torna alla Dashboard</a>
</div>
</body>
</html>