<?php
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$ruolo = $_SESSION['ruolo'];
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 bg-dark text-white p-3">
            <h4>Menù</h4>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                <?php if ($ruolo === 'genitore'): ?>
    <li class="nav-item"><a class="nav-link text-white" href="iscrizioni.php">Iscrivi tuo figlio</a></li>
<?php elseif (in_array($ruolo, ['presidente', 'segretario'])): ?>
    <li class="nav-item"><a class="nav-link text-white" href="iscrizioni.php">Gestisci iscrizioni</a></li>
<?php endif; ?>
                <li class="nav-item"><a class="nav-link text-white" href="quote.php">Quote</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="calendario.php">Calendario</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="distinte.php">Distinte</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="logout.php">Logout</a></li>
            </ul>
            <?php if (in_array($ruolo, ['presidente', 'segretario'])): ?>
    <li class="nav-item"><a class="nav-link text-white" href="approvazioni.php">Approva genitori</a></li>
<?php endif; ?>
        </div>

        <!-- Contenuto -->
        <div class="col-md-9 p-4">
            <h2>Benvenuto, <?= htmlspecialchars($ruolo) ?></h2>
            <p>Qui appariranno gli avvisi e le funzioni disponibili.</p>
        </div>
    </div>
</div>
</body>
</html>