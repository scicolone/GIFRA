<?php
// Configurazione database
$host = "sql.giovannicusumano.it";
$dbname = "giovanni55195";
$username = "giovanni55195";
$password = "giov67316";

// Connessione PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Connessione fallita: " . $e->getMessage());
}

// Avvio sessione
session_start();

// Impostazione fuso orario
date_default_timezone_set('Europe/Rome');
?>