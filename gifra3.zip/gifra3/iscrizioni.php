<?php
include 'config.php';

// Controllo accesso: solo genitori loggati
if (!isset($_SESSION['user_id']) || $_SESSION['ruolo'] !== 'genitore') {
    header("Location: login.php");
    exit;
}

$id_genitore = $_SESSION['user_id'];

// Gestione upload sicuro
function upload_file($file, $prefix) {
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = $prefix . "_" . uniqid() . "." . $ext;
    $target = $target_dir . $filename;
    move_uploaded_file($file['tmp_name'], $target);
    return $filename;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dati base
    $nome = trim($_POST['nome']);
    $cognome = trim($_POST['cognome']);
    $data_nascita = $_POST['data_nascita'];
    $luogo_nascita = trim($_POST['luogo_nascita']);
    $codice_fiscale = strtoupper(trim($_POST['codice_fiscale']));
    $indirizzo = trim($_POST['indirizzo']);

    // Categoria automatica
    $anno = (int)substr($data_nascita, 0, 4);
    $categoria = '';
    if ($anno >= 2020) $categoria = 'Piccoli Amici';
    elseif ($anno >= 2019) $categoria = 'Primi Calci';
    elseif ($anno >= 2017) $categoria = 'Pulcini';
    elseif ($anno >= 2015) $categoria = 'Esordienti';
    elseif ($anno >= 2013) $categoria = 'Giovanissimi';
    elseif ($anno >= 2011) $categoria = 'Allievi';
    else $categoria = 'Allievi';

    // Upload file opzionali
    $foto = isset($_FILES['foto']) && $_FILES['foto']['error'] === 0 ? upload_file($_FILES['foto'], 'foto') : null;
    $doc_file = isset($_FILES['doc_file']) && $_FILES['doc_file']['error'] === 0 ? upload_file($_FILES['doc_file'], 'doc') : null;
    $cert_file = isset($_FILES['cert_file']) && $_FILES['cert_file']['error'] === 0 ? upload_file($_FILES['cert_file'], 'cert') : null;
    $modulo_file = isset($_FILES['modulo_file']) && $_FILES['modulo_file']['error'] === 0 ? upload_file($_FILES['modulo_file'], 'modulo') : null;

    // Inserimento nel database
    $stmt = $pdo->prepare("INSERT INTO calciatori (
        nome, cognome, data_nascita, luogo_nascita, codice_fiscale, indirizzo,
        id_genitore, categoria, foto, doc_tipo, doc_numero, doc_emittente, doc_scadenza, doc_file,
        tessera_figc, tessera_data_emissione, tessera_data_scadenza,
        certificato_data_rilascio, certificato_data_scadenza, certificato_file,
        modulo_iscrizione, genitore_fiscale, cognome_fiscale, nome_fiscale, cf_fiscale,
        data_nascita_fiscale, indirizzo_fiscale, luogo_nascita_fiscale, provincia_nascita_fiscale,
        comune_residenza_fiscale, provincia_residenza_fiscale
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
        $nome, $cognome, $data_nascita, $luogo_nascita, $codice_fiscale, $indirizzo,
        $id_genitore, $categoria, $foto,
        $_POST['doc_tipo'], $_POST['doc_numero'], $_POST['doc_emittente'], $_POST['doc_scadenza'], $doc_file,
        $_POST['tessera_figc'], $_POST['tessera_data_emissione'], $_POST['tessera_data_scadenza'],
        $_POST['certificato_data_rilascio'], $_POST['certificato_data_scadenza'], $cert_file,
        $modulo_file,
        $_POST['genitore_fiscale'],
        $_POST['cognome_fiscale'] ?? '',
        $_POST['nome_fiscale'] ?? '',
        $_POST['cf_fiscale'] ?? '',
        $_POST['data_nascita_fiscale'] ?? null,
        $_POST['indirizzo_fiscale'] ?? '',
        $_POST['luogo_nascita_fiscale'] ?? '',
        $_POST['provincia_nascita_fiscale'] ?? '',
        $_POST['comune_residenza_fiscale'] ?? '',
        $_POST['provincia_residenza_fiscale'] ?? ''
    ]);

    // Notifica email
    $oggetto = "Nuova iscrizione calciatore";
    $messaggio = "Il genitore ID $id_genitore ha iscritto: " . htmlspecialchars($nome) . " " . htmlspecialchars($cognome) . " (CF: $codice_fiscale)";
    @mail("presidente2024@giovannicusumano.it", $oggetto, $messaggio);
    @mail("segretario@giovannicusumano.it", $oggetto, $messaggio);

    $success = "Iscrizione inviata. Riceverai un'email quando sarà approvata.";
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Iscrivi tuo figlio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #secondo-genitore { display: none; }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5" style="max-width: 700px;">
        <h2 class="mb-4 text-center">Iscrivi tuo figlio</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <div class="text-center mt-4">
                <a href="genera_modulo.php?id=<?= $pdo->lastInsertId() ?>" class="btn btn-primary">📄 Genera e scarica modulo PDF</a>
            </div>
        <?php else: ?>
            <form method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">Nome</label><input type="text" name="nome" class="form-control" required></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Cognome</label><input type="text" name="cognome" class="form-control" required></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Data di nascita</label><input type="date" name="data_nascita" class="form-control" required></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Luogo di nascita</label><input type="text" name="luogo_nascita" class="form-control" required></div>
                    <div class="col-md-12 mb-3"><label class="form-label">Codice fiscale</label><input type="text" name="codice_fiscale" class="form-control" required></div>
                    <div class="col-md-12 mb-3"><label class="form-label">Indirizzo</label><input type="text" name="indirizzo" class="form-control" required></div>

                    <div class="col-md-6 mb-3"><label class="form-label">Foto (opzionale)</label><input type="file" name="foto" class="form-control" accept="image/*"></div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Modulo iscrizione firmato (PDF)</label>
                        <input type="file" name="modulo_file" class="form-control" accept=".pdf">
                        <small class="form-text text-muted">Solo file PDF firmati, non immagini.</small>
                    </div>

                    <div class="col-md-4 mb-3"><label class="form-label">Tipo documento</label><input type="text" name="doc_tipo" class="form-control" placeholder="es. Carta d'identità"></div>
                    <div class="col-md-4 mb-3"><label class="form-label">Numero documento</label><input type="text" name="doc_numero" class="form-control"></div>
                    <div class="col-md-4 mb-3"><label class="form-label">Comune emittente</label><input type="text" name="doc_emittente" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Scadenza documento</label><input type="date" name="doc_scadenza" class="form-control" required></div>
                    <div class="col-md-6 mb-3"><label class="form-label">File documento (PDF)</label><input type="file" name="doc_file" class="form-control" accept=".pdf"></div>

                    <div class="col-md-6 mb-3"><label class="form-label">Certificato medico - Data rilascio</label><input type="date" name="certificato_data_rilascio" class="form-control" required></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Certificato medico - Data scadenza</label><input type="date" name="certificato_data_scadenza" class="form-control" required></div>
                    <div class="col-md-12 mb-3"><label class="form-label">Certificato medico (PDF)</label><input type="file" name="cert_file" class="form-control" accept=".pdf"></div>

                    <div class="col-md-6 mb-3"><label class="form-label">Tessera FIGC (opzionale)</label><input type="text" name="tessera_figc" class="form-control"></div>
                    <div class="col-md-3 mb-3"><label class="form-label">Emissione tessera</label><input type="date" name="tessera_data_emissione" class="form-control"></div>
                    <div class="col-md-3 mb-3"><label class="form-label">Scadenza tessera</label><input type="date" name="tessera_data_scadenza" class="form-control"></div>

                    <!-- Genitore fiscale -->
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Il genitore che presenterà la dichiarazione dei redditi è lo stesso che sta compilando?</label>
                        <select name="genitore_fiscale" class="form-select" required onchange="mostraSecondoGenitore(this.value)">
                            <option value="si">Sì</option>
                            <option value="no">No</option>
                        </select>
                    </div>
                </div> <!-- ← CHIUDI il .row principale -->

                <!-- Secondo genitore -->
                <div id="secondo-genitore" class="row g-3">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Cognome</label>
                        <input type="text" name="cognome_fiscale" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nome</label>
                        <input type="text" name="nome_fiscale" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Data di nascita</label>
                        <input type="date" name="data_nascita_fiscale" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Codice fiscale</label>
                        <input type="text" name="cf_fiscale" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Luogo di nascita</label>
                        <input type="text" name="luogo_nascita_fiscale" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Provincia di nascita</label>
                        <input type="text" name="provincia_nascita_fiscale" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Comune di residenza</label>
                        <input type="text" name="comune_residenza_fiscale" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Provincia di residenza</label>
                        <input type="text" name="provincia_residenza_fiscale" class="form-control">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Indirizzo</label>
                        <input type="text" name="indirizzo_fiscale" class="form-control">
                    </div>
                </div>

                <div class="text-center mt-3">
                    <button type="button" class="btn btn-primary" onclick="generaPDF()">
    📄 Genera modulo PDF da firmare
</button>
                    <script>
function generaPDF() {
    const form = document.querySelector('form');
    const data = new FormData(form);
    const params = new URLSearchParams(data);
    window.open('genera_modulo_pdf.php?' + params.toString(), '_blank');
}
</script>
                    <button type="submit" class="btn btn-primary">Invia iscrizione</button>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script>
        function mostraSecondoGenitore(val) {
            const div = document.getElementById('secondo-genitore');
            div.style.display = val === 'no' ? 'block' : 'none';
        }
    </script>
</body>
</html>