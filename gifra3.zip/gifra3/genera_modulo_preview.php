<?php
require_once __DIR__ . '/tcpdf/tcpdf.php';

// Crea nuovo PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Meta
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('ASD Gi.Fra. Milazzo');
$pdf->SetTitle('Modulo Iscrizione');
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->AddPage();

// Font
$pdf->SetFont('helvetica', '', 12);

// Dati dal POST
$nome = $_POST['nome'] ?? '';
$cognome = $_POST['cognome'] ?? '';
$data_nascita = $_POST['data_nascita'] ?? '';
$luogo_nascita = $_POST['luogo_nascita'] ?? '';
$codice_fiscale = $_POST['codice_fiscale'] ?? '';
$categoria = $_POST['categoria'] ?? '';

// Contenuto
$html = <<<EOD
<h2>A.S.D. Gi.Fra. Milazzo – ANNO SPORTIVO 2024/25</h2>
<h3>Modulo Iscrizione</h3>
<p><b>Dati Calciatore</b></p>
<table border="1" cellpadding="4">
 <tr><td width="30%"><b>Nome</b></td><td>$nome</td></tr>
 <tr><td><b>Cognome</b></td><td>$cognome</td></tr>
 <tr><td><b>Data nascita</b></td><td>$data_nascita</td></tr>
 <tr><td><b>Luogo nascita</b></td><td>$luogo_nascita</td></tr>
 <tr><td><b>Codice fiscale</b></td><td>$codice_fiscale</td></tr>
 <tr><td><b>Categoria</b></td><td>$categoria</td></tr>
</table>
EOD;

$pdf->writeHTML($html, true, false, true, false, '');

// Output
$pdf->Output('modulo_iscrizione.pdf', 'D');