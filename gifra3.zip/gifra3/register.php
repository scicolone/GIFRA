<?php
include 'config.php';

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $cognome = trim($_POST['cognome']);
    $email = trim($_POST['email']);
    $password_plain = $_POST['password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email non valida.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM utenti WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email già registrata.";
        } else {
            $password = password_hash($password_plain, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO utenti (nome, cognome, email, password, ruolo, data_nascita, luogo_nascita, provincia_nascita, comune_residenza, provincia_residenza, codice_fiscale, indirizzo, approvato) VALUES (?, ?, ?, ?, 'genitore', ?, ?, ?, ?, ?, ?, ?, 0)");
$stmt->execute([
    $nome, $cognome, $email, $password,
    $_POST['data_nascita'],
    $_POST['luogo_nascita'],
    $_POST['provincia_nascita'],
    $_POST['comune_residenza'],
    $_POST['provincia_residenza'],
    strtoupper($_POST['codice_fiscale']),
    $_POST['indirizzo']
]);

            $oggetto = "Nuova registrazione genitore";
            $messaggio = "Un nuovo genitore si è registrato: $nome $cognome ($email)";
            @mail("presidente@giovannicusumano.it", $oggetto, $messaggio);
            @mail("segretario@giovannicusumano.it", $oggetto, $messaggio);

            header("Location: index.php?registrato=1");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Registrazione Genitore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width: 500px;">
    <h2 class="mb-4 text-center">Registrazione Genitore</h2>
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <form method="POST">
    <div class="mb-3"><label>Nome</label><input type="text" name="nome" class="form-control" required></div>
    <div class="mb-3"><label>Cognome</label><input type="text" name="cognome" class="form-control" required></div>
    <div class="mb-3"><label>Luogo di nascita</label><input type="text" name="luogo_nascita" class="form-control" required></div>
    <div class="mb-3"><label>Provincia di nascita</label><input type="text" name="provincia_nascita" class="form-control" required></div>
    <div class="mb-3"><label>Data di nascita</label><input type="date" name="data_nascita" class="form-control" required></div>
    <div class="mb-3"><label>Codice fiscale</label><input type="text" name="codice_fiscale" class="form-control" required></div>
    <div class="mb-3"><label>Indirizzo</label><input type="text" name="indirizzo" class="form-control" required></div>
    <div class="mb-3"><label>Comune di residenza</label><input type="text" name="comune_residenza" class="form-control" required></div>
    <div class="mb-3"><label>Provincia di residenza</label><input type="text" name="provincia_residenza" class="form-control" required></div>
    <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
    <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
    <button type="submit" class="btn btn-primary w-100">Registrati</button>
</form>
</div>
</body>
</html>