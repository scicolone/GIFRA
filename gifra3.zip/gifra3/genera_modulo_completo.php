<?php
include 'config.php';
require_once 'tcpdf/tcpdf.php';

// Dati calciatore
$nome = $_GET['nome'] ?? '';
$cognome = $_GET['cognome'] ?? '';
$data_nascita = $_GET['data_nascita'] ?? '';
$luogo_nascita = $_GET['luogo_nascita'] ?? '';
$codice_fiscale = $_GET['codice_fiscale'] ?? '';
$indirizzo = $_GET['indirizzo'] ?? '';

// Categoria
$anno = (int)substr($data_nascita, 0, 4);
if ($anno >= 2020) $categoria = 'Piccoli Amici';
elseif ($anno >= 2019) $categoria = 'Primi Calci';
elseif ($anno >= 2017) $categoria = 'Pulcini';
elseif ($anno >= 2015) $categoria = 'Esordienti';
elseif ($anno >= 2013) $categoria = 'Giovanissimi';
elseif ($anno >= 2011) $categoria = 'Allievi';
else $categoria = 'Allievi';

// Dati genitore loggato
$stmt = $pdo->prepare("SELECT nome, cognome, luogo_nascita, provincia_nascita, codice_fiscale, data_nascita, indirizzo, comune_residenza, provincia_residenza FROM utenti WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$gen = $stmt->fetch(PDO::FETCH_ASSOC);

// Secondo genitore (se NO)
$gen2 = [
    'cognome' => $_GET['cognome_fiscale'] ?? '',
    'nome' => $_GET['nome_fiscale'] ?? '',
    'cf' => $_GET['cf_fiscale'] ?? '',
    'data' => $_GET['data_nascita_fiscale'] ?? '',
    'indirizzo' => $_GET['indirizzo_fiscale'] ?? ''
];

// Se stesso
if (($_GET['genitore_fiscale'] ?? 'si') === 'si') {
    $gen2 = $gen;
}

// PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, 'A4', true, 'UTF-8', false);
$pdf->SetCreator('A.S.D. Gi.Fra. Milazzo');
$pdf->SetTitle('Modulo Iscrizione');
$pdf->SetMargins(15, 20, 15);
$pdf->AddPage();

$html = '
<h1 style="text-align:center;">A.S.D. Gi.Fra. Milazzo</h1>
<h2 style="text-align:center;">ANNO SPORTIVO 2024/25<br>MODULO ISCRIZIONE</h2>
<p><strong>Alla S.S.D. Gioventù Francescana Milazzo (GI.FRA.MILAZZO)<br>Piazza San Papino, 3 – 98057 Milazzo (ME)</strong></p>

<p>Il sottoscritto <strong>' . htmlspecialchars($gen['cognome']) . ' ' . htmlspecialchars($gen['nome']) . '</strong> padre/madre del giovane calciatore <strong>' . htmlspecialchars($cognome) . ' ' . htmlspecialchars($nome) . '</strong><br>
nato a <strong>' . htmlspecialchars($luogo_nascita) . '</strong> il <strong>' . htmlspecialchars($data_nascita) . '</strong><br>
residente in <strong>' . htmlspecialchars($indirizzo) . '</strong><br>
codice fiscale <strong>' . htmlspecialchars($codice_fiscale) . '</strong><br>
<strong>Categoria: ' . htmlspecialchars($categoria) . '</strong></p>

<p><strong>DATI DEL GENITORE (per dichiarazione dei redditi)</strong><br>
Cognome: <strong>' . htmlspecialchars($gen['cognome']) . '</strong><br>
Nome: <strong>' . htmlspecialchars($gen['nome']) . '</strong><br>
Luogo di nascita: _________________________ data di nascita: ' . htmlspecialchars($gen['data_nascita']) . '<br>
Residente in: <strong>' . htmlspecialchars($gen['indirizzo']) . '</strong><br>
Codice fiscale: <strong>' . htmlspecialchars($gen['codice_fiscale']) . '</strong></p>';

if (($_GET['genitore_fiscale'] ?? 'si') === 'no') {
    $html .= '<p><strong>DATI DEL SECONDO GENITORE (per scarico fiscale)</strong><br>
    Cognome: <strong>' . htmlspecialchars($gen2['cognome']) . '</strong><br>
    Nome: <strong>' . htmlspecialchars($gen2['nome']) . '</strong><br>
    Luogo di nascita: _________________________ data di nascita: ' . htmlspecialchars($gen2['data']) . '<br>
    Residente in: <strong>' . htmlspecialchars($gen2['indirizzo']) . '</strong><br>
    Codice fiscale: <strong>' . htmlspecialchars($gen2['cf']) . '</strong></p>';
}

$html .= '
<p><strong>CHIEDE</strong><br>di iscrivere il proprio figlio come calciatore alla <strong>S.S.D. Gi.Fra. Milazzo</strong>.</p>

<p>Allega alla presente la quota di iscrizione e si impegna a versare le quote mensili.</p>

<p><strong>DICHIARA:</strong></p>
<ol>
<li>di collaborare con la Società per il trasporto degli atleti;</li>
<li>di avvisare in caso di assenza;</li>
<li>di non interferire in questioni tecniche;</li>
<li>di autorizzare il trattamento dei dati personali;</li>
<li>di conoscere le coperture assicurative;</li>
<li>di esonerare la Società da responsabilità;</li>
<li>di telefonare in caso di assenza in allenamento.</li>
</ol>

<p>Milazzo, ____ / ____ / 2025</p>
<p><strong>Firma del genitore:</strong> __________________________</p>
';

$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('modulo_iscrizione_completo.pdf', 'D');